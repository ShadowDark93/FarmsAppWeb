# FarmsAppWeb
 
Herramienta que permite realizar un aprovechamiento de las nuevas tecnologias a los granjeros con control de inventarios, pesaje de animales y valor comercial del animal.
