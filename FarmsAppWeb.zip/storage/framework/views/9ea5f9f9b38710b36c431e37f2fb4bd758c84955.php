<?php $__env->startSection('css'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.bootstrap4.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio <span
                                            class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item active">
                                    <a class="nav-link" href="<?php echo e(route('farm.index')); ?>">Granjas</a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="<?php echo e(route('inventario.index')); ?>">Inventario</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>

                <div class="card-body">
                    <div class="col-sm mb-3">
                        <div class="row">
                            <div>
                                <a href="<?php echo e(route('farm.create')); ?>" class="btn btn-success float-right">Agregar</a>
                            </div>
                        </div>
                    </div>
                    <?php if($count > 0): ?>
                        <table class="table table-condensed table-bordered table-striped" id="personas">
                            <thead>
                                <tr>
                                    <th scope="col">Nombre</th>
                                    <th scope="col">Nombre Administrador</th>
                                    <th scope="col">Ubicación</th>
                                    <th scope="col">Teléfono</th>
                                    <th scope="col">Operaciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $farms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($farm->Name); ?></th>
                                        <td>
                                            <?php if($farm->AdminName): ?>
                                                <?php echo e($farm->AdminName); ?>

                                            <?php else: ?>
                                                Sin Administrador
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($farm->Location); ?></td>
                                        <td>
                                            <?php if($farm->Phone): ?>
                                                <?php echo e($farm->Phone); ?>

                                            <?php else: ?>
                                                Sin Teléfono
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="container">
                                                <div class="row">
                                                    <a href="<?php echo e(route('farm.edit', $farm->id)); ?>"
                                                        class="btn btn-primary">Editar</a>

                                                    <?php if($farm->state == '1'): ?>
                                                        <a href="<?php echo e(route('farm.disable', $farm->id)); ?>"
                                                            class="btn btn-danger mx-2">Desactivar</a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('farm.enable', $farm->id)); ?>"
                                                            class="btn btn-success mx-2">Activar</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-danger" role="alert">
                            Actualmente no posee registro de propiedades.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/responsive.bootstrap4.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.all.min.js"></script>

    <script>
        $('#personas').DataTable({
            responsive: true,
            autoWidth: false,

            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por página",
                "zeroRecords": "No hay nada para mostrar - disculpa",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "No existen registros disponibles",
                "infoFiltered": "(filtrado de _MAX_ registros totales)",
                "search": "buscar",
                "paginate": {
                    'next': "Siguiente",
                    'previous': "Anterior"
                }
            }
        });

    </script>

    <?php if(session('create') == 'ok'): ?>
        <script>
            Swal.fire({
                icon: 'success',
                position: 'center',
                icon: 'success',
                title: 'La finca se ha creado de manera correcta',
                showConfirmButton: false,
                timer: 3000
            })

        </script>
    <?php endif; ?>

    <?php if(session('edited') == 'ok'): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'La finca ha sido editada',
                showConfirmButton: false,
                timer: 3000
            })

        </script>
    <?php endif; ?>

    <?php if(session('disable') == 'ok'): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'error',
                title: 'La finca ha sido deshabilitada',
                showConfirmButton: false,
                timer: 3000
            })

        </script>
    <?php endif; ?>

    <?php if(session('enable') == 'ok'): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'La finca ha sido habilitada',
                showConfirmButton: false,
                timer: 3000
            })

        </script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FarmsAppWeb\resources\views/farm/index.blade.php ENDPATH**/ ?>