<?php $__env->startSection('contenido'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio <span
                                            class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item active">
                                    <a class="nav-link" href="<?php echo e(route('farm.index')); ?>">Granjas</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('inventario.index')); ?>">Inventario</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>

                <div class="container my-3">
                    <?php echo Form::model($farm, ['route' => ['farm.update', $farm->id], 'method' => 'put']); ?>


                    <div class="form-group mb-3">
                        <?php echo Form::hidden('users_id', Auth()->user()->id, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['AdminName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('AdminName', 'Digite el nombre del Administrador', ['class' => 'form-label']); ?>

                        <?php echo Form::text('AdminName', null, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['AdminName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('Name', 'Digite el nombre de la finca', ['class' => 'form-label']); ?>

                        <?php echo Form::text('Name', null, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['Name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('Location', 'Digite la ubicación de la finca', ['class' => 'form-label']); ?>

                        <?php echo Form::text('Location', null, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['Location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('Phone', 'Digite el teléfono de la finca', ['class' => 'form-label']); ?>

                        <?php echo Form::text('Phone', null, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['Phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <a href="<?php echo e(route('farm.index')); ?>" class="btn btn-info">Volver</a>

                        <?php echo Form::submit('Actualizar Información', ['class' => 'btn btn-success', 'form-control']); ?>

                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FarmsAppWeb\resources\views/farm/edit.blade.php ENDPATH**/ ?>