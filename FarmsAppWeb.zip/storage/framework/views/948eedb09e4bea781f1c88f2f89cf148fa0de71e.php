

<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <?php if(Auth()->user()->estado == 1): ?>
                        <div class="card-header">
                            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav mr-auto">
                                        <li class="nav-item active">
                                            <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio <span
                                                    class="sr-only">(current)</span></a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('farm.index')); ?>">Granjas</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('inventario.index')); ?>">Inventario</a>
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>

                        <div class="card-body">
                            <div class="cotainer">
                                <div class="row">
                                    <div class="col-sm">
                                        <div class="card text-center">
                                            <div class="card-header alert-dark">
                                                Propiedades
                                            </div>
                                            <div class="card-body">
                                                <p class="card-text">
                                                    Actualmente posee <?php echo e($propiedades); ?> propiedades.
                                                </p>
                                                <a href="<?php echo e(route('farm.index')); ?>" class="btn btn-primary">Ir a las
                                                    propiedades.</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm">
                                        <div class="card text-center ">
                                            <div class="card-header alert-dark">
                                                Inventario
                                            </div>
                                            <div class="card-body">
                                                <p class="card-text">
                                                    Actualmente posee <?php echo e($inventario); ?> animales.
                                                </p>
                                                <a href="<?php echo e(route('inventario.index')); ?>" class="btn btn-primary">Ir al
                                                    inventario</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning" role="alert">
                            Estamos procesando su solicitud para poder ingresar su informacion.
                            Por favor sea paciente!.
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FarmsAppWeb\resources\views/usr/home_user.blade.php ENDPATH**/ ?>