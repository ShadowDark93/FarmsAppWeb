

<style>
    input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }

    input[type=number] {
        -moz-appearance: textfield;
    }

</style>

<?php $__env->startSection('contenido'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio</a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="<?php echo e(route('farm.index')); ?>">Granjas</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('inventario.index')); ?>">Inventario<span
                                            class="sr-only"></span></a>
                                </li>
                                <li class="nav-item active">
                                    <a class="nav-link" href="<?php echo e(route('inventario.index')); ?>">Peso<span
                                            class="sr-only">(current)</span></a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <div class="container my-3">
                    <?php echo Form::open(['route' => 'peso.store']); ?>


                    <div class="form-group mb-3">
                        <?php echo Form::hidden('inventories_id', $id, ['class' => 'form-control']); ?>

                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('NombrePesador', 'Digite el nombre del pesador', ['class' => 'form-label']); ?>

                        <?php echo Form::text('NombrePesador', null, ['class' => 'form-control', 'placeholder' => 'Digite el nombre del pesador']); ?>

                        <?php $__errorArgs = ['NombrePesador'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('valor', 'Digite el valor comercial del animal', ['class' => 'form-label']); ?>

                        <?php echo Form::number('valor', null, ['class' => 'form-control', 'placeholder' => 'Digite el valor comercial del animal']); ?>

                        <?php $__errorArgs = ['valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('peso', 'Digite el peso del animal en Kilogramos', ['class' => 'form-label']); ?>

                        <?php echo Form::number('peso', null, ['class' => 'form-control', 'step="any"', 'placeholder' => 'Digite el peso en KG']); ?>

                        <?php $__errorArgs = ['peso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('fechaPeso', 'Digite el peso del animal en Kilogramos', ['class' => 'form-label']); ?>

                        <?php echo Form::date('fechaPeso', null, ['class' => 'form-control', 'step="any"', 'placeholder' => 'Digite el peso en KG']); ?>

                        <?php $__errorArgs = ['fechaPeso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <a href="<?php echo e(route('inventario.index')); ?>" class="btn btn-info">Volver</a>

                        <?php echo Form::submit('Registrar Elemento', ['class' => 'btn btn-success', 'form-control']); ?>

                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FarmsAppWeb\resources\views/peso/create.blade.php ENDPATH**/ ?>