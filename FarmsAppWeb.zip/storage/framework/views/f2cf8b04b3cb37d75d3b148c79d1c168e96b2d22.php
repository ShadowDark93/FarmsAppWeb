<?php $__env->startSection('contenido'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio</a>
                                </li>
                                <li class="nav-item ">
                                    <a class="nav-link" href="<?php echo e(route('farm.index')); ?>">Granjas</a>
                                </li>
                                <li class="nav-item active">
                                    <a class="nav-link" href="<?php echo e(route('inventario.index')); ?>">Inventario<span
                                            class="sr-only">(current)</span></a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <div class="container my-3">
                    <?php echo Form::open(['route' => 'inventario.store']); ?>


                    <div class="form-group mb-3">
                        <?php echo Form::hidden('users_id', Auth()->user()->id, ['class' => 'form-control']); ?>

                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('farms_id', 'Seleccione la finca', ['class' => 'form-label']); ?>

                        <?php echo Form::select('farms_id', $farms->pluck('Name', 'id'), null, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['farms_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('InternalCode', 'Digite el código interno del animal', ['class' => 'form-label']); ?>

                        <?php echo Form::text('InternalCode', null, ['class' => 'form-control', 'placeholder' => 'Código Interno']); ?>

                        <?php $__errorArgs = ['InternalCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('Category', 'Digite la especie del animal', ['class' => 'form-label']); ?>

                        <?php echo Form::text('Category', null, ['class' => 'form-control', 'placeholder' => 'Especie']); ?>

                        <?php $__errorArgs = ['Category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('Sex', 'Digite el sexo del animal', ['class' => 'form-label']); ?>

                        <?php echo Form::select('Sex', ['M' => 'Masculino', 'F' => 'Femenino'], 1, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['Sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('ThirdLabel', 'El animal esta tercerizado?', ['class' => 'form-label']); ?>

                        <?php echo Form::select('Third', ['0' => 'No', '1' => 'Si'], 0, ['class' => 'form-control']); ?>

                        <?php $__errorArgs = ['Third'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <?php echo Form::label('ThirdName', 'Digite el nombre del tercero', ['class' => 'form-label']); ?>

                        <?php echo Form::text('ThirdName', null, ['class' => 'form-control', 'placeholder' => 'Nombre del tercero']); ?>

                        <?php $__errorArgs = ['ThirdName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger">Este campo es requerido</span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div>
                        <a href="<?php echo e(route('inventario.index')); ?>" class="btn btn-info">Volver</a>

                        <?php echo Form::submit('Registrar Elemento', ['class' => 'btn btn-success', 'form-control']); ?>

                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FarmsAppWeb\resources\views/inventory/create.blade.php ENDPATH**/ ?>