

<?php $__env->startSection('contenido'); ?>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav mr-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Inicio </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('farm.index')); ?>">Granjas</a>
                                </li>
                                <li class="nav-item active">
                                    <a class="nav-link" href="<?php echo e(route('inventario.index')); ?>">Inventario<span
                                            class="sr-only">(current)</span></a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>

                <div class="card-body">

                    <div class="col-sm mb-3">
                        <div class="row">
                            <div class="sm-6">
                                <h4 style="color:green" class="float-right"> Valor total inventario:
                                    <span><?php echo e($total); ?></span>
                                </h4>
                            </div>
                        </div>

                        <div class="row">
                            <div class="sm-6">
                                <a href="<?php echo e(route('inventario.create')); ?>" class="btn btn-success float-left">Agregar</a>
                            </div>
                        </div>

                    </div>

                    <?php if($data->count() > 0): ?>
                        <table id="inventario"
                            class="table table-striped table-hover table-bordered table-responsive{-sm|-md|-lg|-xl|-xxl">
                            <thead class="table-dark">
                                <tr>
                                    <th scope="col">Código Interno</>
                                    <th scope="col">Ubicación</th>
                                    <th scope="col">Categoría</th>
                                    <th scope="col">Sexo</th>
                                    <th scope="col">Tercerizado</th>
                                    <th scope="col">Nombre Tercero</th>
                                    <th scope="col">Peso</th>
                                    <th scope="col">Valor</th>
                                    <th scope="col">Estado</th>
                                    <th scope="col">Operaciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($d->InternalCode); ?></th>
                                        <td><?php echo e($d->farm->Name); ?></td>
                                        <td>
                                            <?php if($d->Category == '1'): ?>
                                                Ganado vacuno o bovino
                                            <?php elseif($d->Category=='2'): ?>
                                                Ganado aviar
                                            <?php elseif($d->Category=='3'): ?>
                                                Ganado equino
                                            <?php elseif($d->Category=='4'): ?>
                                                Ganado porcino
                                            <?php elseif($d->Category=='5'): ?>
                                                Ganado ovino
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($d->Sex); ?></td>
                                        <td>
                                            <?php if($d->third == 1): ?>
                                                Sí
                                            <?php else: ?>
                                                No
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($d->third == 1): ?>
                                                <?php echo e($d->ThirdName); ?>

                                            <?php else: ?>
                                                No aplica.
                                            <?php endif; ?>
                                        </td>
                                        <th>
                                            <?php if($d->peso != null): ?>
                                                <?php echo e($d->peso); ?> KG
                                            <?php else: ?>
                                                Sin peso registrado
                                            <?php endif; ?>
                                        </th>
                                        <th>
                                            <?php if($d->valor != null): ?>
                                                <?php echo e($d->valor); ?> Pesos
                                            <?php else: ?>
                                                Sin valor registrado
                                            <?php endif; ?>
                                        </th>
                                        <td>
                                            <?php if($d->state == 1): ?>
                                                Activo
                                            <?php elseif($d->state==2): ?>
                                                Vendido
                                            <?php elseif($d->state==3): ?>
                                                Trasladado
                                            <?php elseif($d->state==0): ?>
                                                Muerto
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($d->state != 1): ?>
                                                <span class="badge badge-danger">No se puede modificar este animal</span>
                                                <a href="<?php echo e(route('peso.show', 0)); ?>"
                                                    class="btn btn-sm btn-warning">Pesaje y Valor</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('inventario.edit', $d->id)); ?>"
                                                    class="btn btn-primary">Editar</a>
                                                <a href="<?php echo e(route('peso.show', $d->id)); ?>"
                                                    class="btn btn-sm btn-warning">Pesaje y Valor</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="alert alert-danger" role="alert">
                            Actualmente no posee registro de inventario.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.6/js/responsive.bootstrap4.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.6/dist/sweetalert2.all.min.js"></script>

    <script>
        $('#inventario').DataTable({
            responsive: true,
            autoWidth: false,

            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por página",
                "zeroRecords": "No hay nada para mostrar - disculpa",
                "info": "Mostrando _PAGE_ de _PAGES_",
                "infoEmpty": "No existen registros disponibles",
                "infoFiltered": "(filtrado de _MAX_ registros totales)",
                "search": "buscar",
                "paginate": {
                    'next': "Siguiente",
                    'previous': "Anterior"
                }
            }
        });
    </script>

    <?php if(session('created') == 'ok'): ?>
        <script>
            Swal.fire({
                icon: 'success',
                position: 'center',
                icon: 'success',
                title: 'El elemento se ha creado de manera correcta',
                showConfirmButton: false,
                timer: 3000
            })
        </script>
    <?php endif; ?>

    <?php if(session('edited') == 'ok'): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'El elemento ha sido editado de manera correcta',
                showConfirmButton: false,
                timer: 3000
            })
        </script>
    <?php endif; ?>

    <?php if(session('disable') == 'ok'): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'error',
                title: 'El elemento ha sido dado de baja',
                showConfirmButton: false,
                timer: 3000
            })
        </script>
    <?php endif; ?>

    <?php if(session('enable') == 'ok'): ?>
        <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'La finca ha sido habilitada',
                showConfirmButton: false,
                timer: 3000
            })
        </script>
    <?php endif; ?>

    
    <script>
        $("#valor").on({
            "focus": function(event) {
                $(event.target).select();
            },
            "keyup": function(event) {
                $(event.target).val(function(index, value) {
                    return value.replace(/\D/g, "")
                        .replace(/([0-9])([0-9]{2})$/, '$1.$2')
                        .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
                });
            }
        });
    </script>

    <script>
        $("#Peso").on({
            "focus": function(event) {
                $(event.target).select();
            },
            "keyup": function(event) {
                $(event.target).val(function(index, value) {
                    return value.replace(/\D/g, "")
                        .replace(/([0-9])([0-9]{2})$/, '$1.$2')
                        .replace(/\B(?=(\d{3})+(?!\d)\.?)/g, ",");
                });
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FarmsAppWeb\resources\views/inventory/index.blade.php ENDPATH**/ ?>