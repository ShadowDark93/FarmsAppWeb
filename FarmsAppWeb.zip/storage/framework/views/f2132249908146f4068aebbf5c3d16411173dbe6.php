<?php $__env->startSection('contenido'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <h1 align="center" style="font-weight: bold; color: #ed502e " class="p-4">ACTIVACIÓN DE PERSONAS</h1>



                        <table class="table table-striped table-hover table-bordered border-primary">
                            <thead class="table-dark">
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">NOMBRE DEL USUARIO</th>
                                    <th scope="col">CORREO</th>
                                    <th colspan="2">ACCIONES</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($user->id); ?></th>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->estado=='0'): ?>
                                        <a href="" class="btn btn-success form-control">Activar</a>
                                        <?php else: ?>
                                        <a href="" class="btn btn-danger form-control">Desactivar</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FarmsAppWeb\resources\views/home_admin.blade.php ENDPATH**/ ?>