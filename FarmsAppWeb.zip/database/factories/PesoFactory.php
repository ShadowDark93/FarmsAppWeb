<?php

namespace Database\Factories;

use App\Models\Peso;
use Illuminate\Database\Eloquent\Factories\Factory;

class PesoFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Peso::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
